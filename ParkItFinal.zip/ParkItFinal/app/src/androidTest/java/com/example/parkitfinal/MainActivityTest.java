package com.example.parkitfinal;

import static org.junit.Assert.*;

public class MainActivityTest {

}