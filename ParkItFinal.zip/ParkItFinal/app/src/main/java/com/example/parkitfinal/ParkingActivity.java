package com.example.parkitfinal;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

import static android.Manifest.permission.ACCESS_FINE_LOCATION;


public class ParkingActivity extends AppCompatActivity {
    private FusedLocationProviderClient client;
    private Button proceed;
    private Activity rootView;


    protected void onCreate(Bundle savedInstanceState) {
        Button proceed = (Button)rootView.findViewById(R.id.proceed);

        proceed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ParkingActivity.this, ParkingReceiptActivity.class));
            }
        });
        int latitude = 0;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        client= LocationServices.getFusedLocationProviderClient(this);


        requestPermission();

        Button button = (Button)rootView.findViewById(R.id.button);
        final int finalLatitude = latitude;
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

                if (ActivityCompat.checkSelfPermission(ParkingActivity.this, ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED ) {

                    return;
                }
                client.getLastLocation().addOnSuccessListener(ParkingActivity.this, new OnSuccessListener<Location>() {

                    public void onSuccess(Location location) {

                        if(location!= null){
                            TextView loc1 = findViewById(R.id.loc1);
                            loc1.setText(location.toString());
                            FirebaseDatabase database = FirebaseDatabase.getInstance();
                            DatabaseReference myRef = database.getReference();
                            HashMap<String, Integer> map = new HashMap<>();
                            map.put("coordinates", finalLatitude);

                        }

                    }
                });

            }
        });
        Button button2 = (Button)rootView.findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

                if (ActivityCompat.checkSelfPermission(ParkingActivity.this, ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED ) {

                    return;
                }
                client.getLastLocation().addOnSuccessListener(ParkingActivity.this, new OnSuccessListener<Location>() {

                    public void onSuccess(Location location) {

                        if(location!= null){
                            TextView loc2 = findViewById(R.id.loc2);
                            loc2.setText(location.toString());
                            FirebaseDatabase database = FirebaseDatabase.getInstance();
                            DatabaseReference myRef = database.getReference();
                            HashMap<String, Integer> map = new HashMap<>();
                            map.put("coordinates", finalLatitude);
                        }

                    }
                });

            }
        });
        Button button3 = (Button)rootView.findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

                if (ActivityCompat.checkSelfPermission(ParkingActivity.this, ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED ) {

                    return;
                }
                client.getLastLocation().addOnSuccessListener(ParkingActivity.this, new OnSuccessListener<Location>() {

                    public void onSuccess(Location location) {

                        if(location!= null){
                            TextView loc3 = findViewById(R.id.loc3);
                            loc3.setText(location.toString());
                            FirebaseDatabase database = FirebaseDatabase.getInstance();
                            DatabaseReference myRef = database.getReference();
                            HashMap<String, Integer> map = new HashMap<>();
                            map.put("coordinates", finalLatitude);
                        }

                    }
                });

            }
        });
        Button button4 = (Button)rootView.findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

                if (ActivityCompat.checkSelfPermission(ParkingActivity.this, ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED ) {

                    return;
                }
                client.getLastLocation().addOnSuccessListener(ParkingActivity.this, new OnSuccessListener<Location>() {

                    public void onSuccess(Location location) {

                        if(location!= null){
                            TextView loc4 = findViewById(R.id.loc4);
                            loc4.setText(location.toString());
                            FirebaseDatabase database = FirebaseDatabase.getInstance();
                            DatabaseReference myRef = database.getReference();
                            HashMap<String, Integer> map = new HashMap<>();
                            map.put("coordinates", finalLatitude);
                        }

                    }
                });

            }
        });
    }

    private void requestPermission(){
        ActivityCompat.requestPermissions(this, new String[]{ACCESS_FINE_LOCATION}, 1);
    }
}


