package com.example.parkitfinal;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class ParkingReceiptActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parking_receipt);
    }
}
