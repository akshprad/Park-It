package com.example.parkitfinal;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import android.widget.TextView;
import static com.example.parkitfinal.R.id.s1;



public class ParkingReceiptActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parking_receipt);

    /*   EditText sl1;
        sl1 = (EditText) findViewById(R.id.s1);
        String passedArg = getIntent().getExtras().getString("Slot-1");
        sl1.setText(passedArg);

        EditText sl2;
        sl1 = (EditText) findViewById(R.id.s2);
        String passedArg1 = getIntent().getExtras().getString("Slot-2");
        sl1.setText(passedArg);

        EditText sl3;
        sl1 = (EditText) findViewById(R.id.s3);
        String passedArg2 = getIntent().getExtras().getString("Slot-3");
        sl1.setText(passedArg);

        EditText sl4;
        sl1 = (EditText) findViewById(R.id.s4);
        String passedArg3 = getIntent().getExtras().getString("Slot-4");
        sl1.setText(passedArg);*/



    }
}
